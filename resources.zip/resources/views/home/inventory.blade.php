<section class="iq-solutions pt-0 bg-light" >
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center">
                <div class="section-title">
                    {{-- <p class="mt-2 text-uppercase iq-fw-3 iq-ls-3">Best Ever Services</p>--}}
                    <h2 class="title  iq-fw-8">Adbliv Inventory</h2>
                </div>
            </div>
        </div>
        <div class="row flex-row-reverse">
            <div class="col-lg-6 align-self-center wow fadeInRight"
                 style="visibility: visible; animation-name: fadeInRight;">
                <p class="mb-3"><strong class="text-black">"Adbliv"</strong> has the most enriched Inventory
                    .<strong class="text-black">"Inventory"</strong> Among the all Ad Networks We have around.
                </p>
                <p class="mb-3"><strong class="text-black">80% Premium Placements</strong> In all local portals in our
                    country.
                </p>

            </div>
            <div class="col-lg-6">
                <img width="80%" src="/images/inventory.png" class="img-fluid wow fadeInLeft" alt=""
                     style="visibility: visible; animation-name: fadeInLeft;">
            </div>
        </div>
    </div>
</section>
