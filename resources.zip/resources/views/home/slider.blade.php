{{--
<div class="iq-banner">
    <div id="rev_slider_3_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="marketive-1"
         style="margin:0px auto;background-color:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
        <!-- START REVOLUTION SLIDER 5.2.6 fullwidth mode -->
        <div id="rev_slider_3_1" class="rev_slider fullwidthabanner tp-overflow-hidden" style="display:none;"
             data-version="5.2.6">
            <ul>  <!-- SLIDE  -->
                <li data-index="rs-2" data-transition="fade" data-slotamount="default" data-hideafterloop="0"
                    data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="600"
                    data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2=""
                    data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8=""
                    data-param9="" data-param10="" data-description="">
                    <!-- MAIN IMAGE -->
                    <img src="/revslider/assets/02f6c-bg.jpg" alt="" data-bgposition="center center" data-bgfit="cover"
                         data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <!-- LAYER NR. 1 -->
                    <h1 class="tp-caption   tp-resizeme"
                        id="slide-2-layer-14"
                        data-x="29"
                        data-y="center" data-voffset="-105"
                        data-width="['auto']"
                        data-height="['auto']"
                        data-transform_idle="o:1;"

                        data-transform_in="x:50px;opacity:0;s:1000;e:Power4.easeInOut;"
                        data-transform_out="opacity:0;s:300;"
                        data-start="500"
                        data-splitin="none"
                        data-splitout="none"
                        data-responsive_offset="on"

                        style="z-index: 5; white-space: nowrap; font-size: 60px; line-height: 70px; font-weight: 700; color: rgba(27, 14, 61, 1.00);font-family:Nunito;">
                        Welcome To <br> ADBLiv </h1>
                    <!-- LAYER NR. 2 -->
                    <p class="tp-caption   tp-resizeme"
                       id="slide-2-layer-2"
                       data-x="30"
                       data-y="center" data-voffset="22"
                       data-width="['auto']"
                       data-height="['auto']"
                       data-transform_idle="o:1;"

                       data-transform_in="x:50px;opacity:0;s:1000;e:Power2.easeInOut;"
                       data-transform_out="opacity:0;s:300;"
                       data-start="500"
                       data-splitin="none"
                       data-splitout="none"
                       data-responsive_offset="on"

                       style="z-index: 6; white-space: nowrap; font-size: 18px; line-height: 32px; font-weight: 400; color: rgba(134, 136, 148, 1.00);font-family:Poppins;">
                        The UAE-based advertising network <br>  </p>
                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption rev-btn button button-sm rev-withicon  tp-resizeme rs-hover-ready"
                         id="slide-2-layer-4"
                         data-x="29"
                         data-y="480"
                         data-width="['auto']"
                         data-height="['auto']"
                         data-transform_idle="o:1;"
                         data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:0;e:Linear.easeNone;"
                         data-style_hover="c:rgba(255, 255, 255, 1.00);bg:rgba(124, 96, 213, 1.00);"

                         data-transform_in="x:50px;opacity:0;s:1000;e:Power4.easeOut;"
                         data-transform_out="opacity:0;s:300;e:Back.easeIn;"
                         data-start="500"
                         data-splitin="none"
                         data-splitout="none"
                         data-responsive_offset="on"

                         style="z-index: 7; white-space: nowrap; font-size: 18px; line-height: 50px;height:auto; font-weight: 300; color: rgba(255, 255, 255, 1.00);font-family:Nunito;padding:0px 35px 0px 35px;border-color:rgba(0, 0, 0, 1.00);border-radius:30px 30px 30px 30px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">
                        Start a Project
                    </div>
                    <!-- LAYER NR. 4 -->
                    <span class="tp-caption   tp-resizeme"
                          id="slide-2-layer-13"
                          data-x="31"
                          data-y="538"
                          data-width="['auto']"
                          data-height="['auto']"
                          data-transform_idle="o:1;"

                          data-transform_in="x:50px;opacity:0;s:1000;e:Power2.easeInOut;"
                          data-transform_out="opacity:0;s:300;"
                          data-start="500"
                          data-splitin="none"
                          data-splitout="none"
                          data-responsive_offset="on"

                          style="z-index: 8; white-space: nowrap; font-size: 12px; line-height: 32px; font-weight: 400; color: rgba(134, 136, 148, 1.00);font-family:Poppins;">*Start Your Project With Us Today! </span>
                    <!-- LAYER NR. 5 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-2-layer-5"
                         data-x="727"
                         data-y="166"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.8;sY:0.8;skX:0;skY:0;opacity:0;s:1000;e:Power4.easeOut;"
                         data-transform_out="opacity:0;s:300;"
                         data-start="1020"
                         data-responsive_offset="on"

                         style="z-index: 9;"><img src="/revslider/assets/edad9-08.png" alt="" data-ww="636px"
                                                  data-hh="411px" data-no-retina></div>
                    <!-- LAYER NR. 6 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-2-layer-7"
                         data-x="895"
                         data-y="238"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.8;sY:0.8;skX:0;skY:0;opacity:0;s:1000;e:Power4.easeOut;"
                         data-transform_out="opacity:0;s:300;e:Back.easeIn;"
                         data-start="1350"
                         data-responsive_offset="on"

                         style="z-index: 10;"><img src="" alt="" data-ww="auto"
                                                   data-hh="auto" data-no-retina></div>
                    <!-- LAYER NR. 7 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-2-layer-8"
                         data-x="1045"
                         data-y="235"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.8;sY:0.8;skX:0;skY:0;opacity:0;s:1000;e:Power4.easeOut;"
                         data-transform_out="opacity:0;s:300;e:Back.easeIn;"
                         data-start="1360"
                         data-responsive_offset="on"

                         style="z-index: 11;"><img src="" alt="" data-ww="auto"
                                                   data-hh="auto" data-no-retina></div>
                    <!-- LAYER NR. 8 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-2-layer-9"
                         data-x="1196"
                         data-y="231"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.8;sY:0.8;skX:0;skY:0;opacity:0;s:1000;e:Power4.easeOut;"
                         data-transform_out="opacity:0;s:300;e:Back.easeIn;"
                         data-start="1390"
                         data-responsive_offset="on"

                         style="z-index: 12;"><img src="/revslider/assets/7ae95-06.png" alt="" data-ww="auto"
                                                   data-hh="auto" data-no-retina></div>
                    <!-- LAYER NR. 9 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-2-layer-17"
                         data-x="858"
                         data-y="330"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeInOut;"
                         data-transform_out="opacity:0;s:300;"
                         data-start="2620"
                         data-responsive_offset="on"

                         style="z-index: 13;"><img src="/revslider/assets/b2422-10.png" alt="" data-ww="auto"
                                                   data-hh="auto" data-no-retina></div>
                    <!-- LAYER NR. 10 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-2-layer-15"
                         data-x="798"
                         data-y="491"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1000;e:Power4.easeInOut;"
                         data-transform_out="opacity:0;s:300;"
                         data-start="1880"
                         data-responsive_offset="on"

                         style="z-index: 14;"><img src="/revslider/assets/bc86e-12.png" alt="" data-ww="537px"
                                                   data-hh="250px" data-no-retina></div>
                    <!-- LAYER NR. 11 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-2-layer-16"
                         data-x="1128"
                         data-y="353"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:50px;opacity:0;s:1000;e:Power2.easeInOut;"
                         data-transform_out="opacity:0;s:300;"
                         data-start="2360"
                         data-responsive_offset="on"

                         style="z-index: 15;"><img src="/revslider/assets/b1482-09.png" alt="" data-ww="auto"
                                                   data-hh="auto" data-no-retina></div>
                    <!-- LAYER NR. 12 -->
                    <div class="tp-caption   tp-resizeme"
                         id="slide-2-layer-18"
                         data-x="764"
                         data-y="342"
                         data-width="['none','none','none','none']"
                         data-height="['none','none','none','none']"
                         data-transform_idle="o:1;"

                         data-transform_in="x:-50px;opacity:0;s:1000;e:Power2.easeInOut;"
                         data-transform_out="opacity:0;s:300;"
                         data-start="2750"
                         data-responsive_offset="on"

                         style="z-index: 16;"><img src="/revslider/assets/b33c3-11.png" alt="" data-ww="auto"
                                                   data-hh="auto" data-no-retina></div>
                </li>
                <!-- SLIDE  -->
            </ul>
            <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
        </div>
    </div>
</div>
--}}

<div id="demo" class="carousel slide" data-ride="carousel">

    <!-- Indicators -->
    <ul class="carousel-indicators">
        <li data-target="#demo" data-slide-to="0" class="active"></li>
        <li data-target="#demo" data-slide-to="1"></li>
        <li data-target="#demo" data-slide-to="2"></li>
    </ul>

    <!-- The slideshow -->
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="/images/sl1.jpg" alt="Slider" class="slider" width="100%" height="auto">
           {{-- <div class="carousel-caption text-left">
                <h3>Ad Networks</h3>
                <p>Boost your business with an all-in-one solution</p>
            </div>
--}}
        </div>
        <div class="carousel-item">
            <img src="/images/sl2.jpg" alt="Slider" class="slider" width="100%" height="auto">

        </div>
        <div class="carousel-item">
            <img src="/images/sl3.jpg" alt="Slider" class="slider" width="100%" height="auto">

        </div>
    </div>

    <!-- Left and right controls -->
    <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
    </a>
</div>
