<header id="main-header" class="header-one">
    <!-- menu start -->
    <nav id="menu-1" class="mega-menu" data-color="">
        <!-- menu list items container -->
        <div class="menu-list-items">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <!-- menu logo -->
                        <ul class="menu-logo">
                            <li>
                                <a href="/"><img src="/images/Adbiliv-png.png" alt="logo" class="img-fluid"></a>
                            </li>
                        </ul>
                        <!-- menu search bar -->
                        <!-- menu links -->
                        <ul class="menu-links">
                            <!-- active class -->
                            <li >
                                <a href="/" class="active">Home</a>

                            </li>
                            <li>
                                <a href="#about">About</a>
                                <!-- drop down full width -->

                            </li>
                          {{--  <li>
                                <a href="#portfolio">Portfolio</a>

                            </li>--}}
                            <li>
                                <a href="#services">Our Services</a>

                            </li>
                            <li>
                                <a href="#gallery">Gallery</a>

                            </li>
                            <li>
                                <a href="#advertiser">Advertiser</a>

                            </li>


                            <li><a href="#contact">Contact us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- menu end -->
</header>
